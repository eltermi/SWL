SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://sitters:gatos@localhost/SWL'
SQLALCHEMY_TRACK_MODIFICATIONS = False
